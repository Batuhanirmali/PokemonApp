//
//  DetailViewController.swift
//  PokemonTaskChallenge
//
//  Created by Talha Batuhan Irmalı on 23.03.2023.
//

import UIKit

class DetailViewController: UIViewController {

    var pokemonName: String?
    var pokemonImageURL: URL?
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var abilities: UILabel!
    @IBOutlet weak var abilities2: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameLabel.text = pokemonName
                
        if let imageURL = pokemonImageURL {
            loadImage(from: imageURL)
        }
        
    }
    
    private func loadImage(from url: URL) {
            URLSession.shared.dataTask(with: url) { (data, response, error) in
                guard let data = data else { return }
                DispatchQueue.main.async {
                    self.imageView.image = UIImage(data: data)
                }
            }.resume()
        }
}
 
