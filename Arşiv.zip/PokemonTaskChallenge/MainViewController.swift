//
//  ViewController.swift
//  PokemonTaskChallenge
//
//  Created by Talha Batuhan Irmalı on 22.03.2023.
//

import UIKit

class MainViewController: UIViewController {
    
    private var pokemons: [GetPokemonsResponse.Pokemon] = []
    private var activityIndicatorView: UIActivityIndicatorView!

    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        self.tableView.register(UINib(nibName: "PokemonTableViewCell", bundle: nil), forCellReuseIdentifier: "cell")
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        activityIndicatorView = UIActivityIndicatorView(style: .large)
        activityIndicatorView.center = tableView.center
        tableView.addSubview(activityIndicatorView)
        
        activityIndicatorView.startAnimating()
        getPokemons()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "showDetail", let detailVC = segue.destination as? DetailViewController, let indexPath = tableView.indexPathForSelectedRow {
                let pokemon = pokemons[indexPath.row]
                detailVC.pokemonName = pokemon.name
                detailVC.pokemonImageURL = PokeAPIService.shared.getPokemonSprites(id: pokemon.pokemonID)
            }
        }
    
    private func getPokemons() {
            PokeAPIService.shared.getPokemons { response in
                self.pokemons = response.results
                DispatchQueue.main.async {
                    self.activityIndicatorView.stopAnimating()
                    self.tableView.reloadData()
                }
            }
        }
}
extension MainViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pokemons.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "cell",for: indexPath) as? PokemonTableViewCell {
            let pokemon = pokemons[indexPath.row]
            cell.nameLabel.text = pokemons[indexPath.row].name
            cell.loadImage(from: PokeAPIService.shared.getPokemonSprites(id: pokemon.pokemonID))
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "showDetail", sender: self)
    }
}


